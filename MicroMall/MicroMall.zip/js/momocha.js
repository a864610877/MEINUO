$.getScript('/js/momocha-min.js',function(){
	fit();
	mosidebar();
	spnr();
	act0();
	act1();
	zf();
});