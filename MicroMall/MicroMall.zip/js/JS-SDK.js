﻿var dataForWeixin ={
    appId:"",
    timestamp:"",
    nonceStr:"",
    signature: "",
    ImageUrl:"",
};
var httpurl = location.href.split('#')[0];
$.ajax({
    url: "/Weixin/WebConfing",
    data:{url:httpurl},
    type: "post",
    dataType: "json",
    async: false,
    success: function (data) {
        if (data != null) {
            dataForWeixin.appId = data.appId;
            dataForWeixin.nonceStr = data.nonceStr;
            dataForWeixin.signature = data.signature;
            dataForWeixin.timestamp = data.timestamp;
            dataForWeixin.ImageUrl = data.ImageUrl;
        }
    }
});
wx.config({
    debug: true, // 开启调试模式,调用的所有api的返回值会在客户端alert出来，若要查看传入的参数，可以在pc端打开，参数信息会通过log打出，仅在pc端时才会打印。
    appId: dataForWeixin.appId, // 必填，公众号的唯一标识
    timestamp:dataForWeixin.timestamp , // 必填，生成签名的时间戳
    nonceStr: dataForWeixin.nonceStr, // 必填，生成签名的随机串
    signature: dataForWeixin.signature,// 必填，签名，见附录1
    jsApiList: ['onMenuShareTimeline'] // 必填，需要使用的JS接口列表，所有JS接口列表见附录2
});
wx.checkJsApi({
    jsApiList: ['chooseImage'], // 需要检测的JS接口列表，所有JS接口列表见附录2,
    success: function(res) {
        // 以键值对的形式返回，可用的api值true，不可用为false
        // 如：{"checkResult":{"chooseImage":true},"errMsg":"checkJsApi:ok"}
    }
});

wx.ready(function(){

    // config信息验证后会执行ready方法，所有接口调用都必须在config接口获得结果之后，config是一个客户端的异步操作，所以如果需要在页面加载时就调用相关接口，则须把相关接口放在ready函数中调用来确保正确执行。对于用户触发时才调用的接口，则可以直接调用，不需要放在ready函数中。
});

wx.error(function(res){

    // config信息验证失败会执行error函数，如签名过期导致验证失败，具体错误信息可以打开config的debug模式查看，也可以在返回的res参数中查看，对于SPA可以在这里更新签名。

});

function ShareTimeline() {
    $.openLoading("分享中");
    wx.onMenuShareTimeline({
        title: '快点加入雷鹏汽车用品吧(扫描二维码)', // 分享标题
        link: '#', // 分享链接
        imgUrl: dataForWeixin.ImageUrl, // 分享图标
        success: function () {
            $.closeLoading();
            $.openSuccessMessage("分享成功");
            // 用户确认分享后执行的回调函数
        },
        cancel: function () {
            $.closeLoading();
            $.openErrorMessage("分享失败");
            // 用户取消分享后执行的回调函数
        }
    });
}
//wx.onMenuShareTimeline({
//    title: '分享赢取积分', // 分享标题
//    link: '#', // 分享链接
//    imgUrl: '', // 分享图标
//    success: function () { 
//        // 用户确认分享后执行的回调函数
//    },
//    cancel: function () { 
//        // 用户取消分享后执行的回调函数
//    }
//});

