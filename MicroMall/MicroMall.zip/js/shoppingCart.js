﻿//$(function () {
//    $("[name=xz]").click(function () {
//        $(".bgFFF").each(function () {
//            if($(this))
//        })
//    });
//});